@echo off
chcp 1251 >nul
title �������� ����������
setlocal enabledelayedexpansion
if not exist "..\config\settings.ini" (
    exit /b 1
)
for /f "tokens=2 delims==" %%i in ('type "..\config\settings.ini" ^| find "PROJECT_PATH"') do set "PROJECT_PATH=%%i"
set "STATS_FILE=%PROJECT_PATH%logs\statistics.ini"
if not exist "%STATS_FILE%" (
    echo [STATISTICS] > "%STATS_FILE%"
    echo TOTAL_BACKUPS=0 >> "%STATS_FILE%"
    echo TOTAL_RESTORES=0 >> "%STATS_FILE%"
    echo TOTAL_FILES_COPIED=0 >> "%STATS_FILE%"
    echo TOTAL_BYTES_COPIED=0 >> "%STATS_FILE%"
    echo LAST_BACKUP_DATE=������� >> "%STATS_FILE%"
    echo LAST_RESTORE_DATE=������� >> "%STATS_FILE%"
    echo FLASH_G_BACKUPS=0 >> "%STATS_FILE%"
    echo FLASH_L_BACKUPS=0 >> "%STATS_FILE%"
    echo FLASH_G_RESTORES=0 >> "%STATS_FILE%"
    echo FLASH_L_RESTORES=0 >> "%STATS_FILE%"
    echo FIRST_USE=%date% %time% >> "%STATS_FILE%"
)
exit /b 0